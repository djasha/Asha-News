# TradingView Panel - Directus extension

A directus panel that show tradingview charts.
